package com.payment.gateway.entity.enums;

public enum TaskStatus {
  SCHEDULED,
  PROCESSING,
  SUCCESS,
  CANCELED,
  FAILED
}
