package com.payment.gateway.service;

public interface WorkflowService {

}
