package com.payment.gateway.service;

public interface DataPayloadService {
}
